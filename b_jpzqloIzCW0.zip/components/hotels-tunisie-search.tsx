"use client"

import { useState, useMemo, useCallback } from "react"
import { format } from "date-fns"
import { fr } from "date-fns/locale"
import { MapPin, Calendar, Users, Star, X, Plus, Minus, Search, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"

// ============================================================================
// Types matching MyGo API Schema
// ============================================================================

interface City {
  id: number
  name: string
  region?: string
}

interface Pax {
  Adult: number
  Child: number[] // Array of ages (0-17)
}

interface BookingDetails {
  Checkin: string // YYYY-MM-DD
  Checkout: string // YYYY-MM-DD
}

interface Filters {
  OnlyAvailable: boolean
  Category: number[] // Stars array [3, 4, 5]
}

interface HotelSearchRequest {
  CityId: number
  BookingDetails: BookingDetails
  Pax: Pax
  Filters: Filters
}

// ============================================================================
// Mock Cities Data (to be replaced by API ListCity)
// ============================================================================

const TUNISIA_CITIES: City[] = [
  { id: 1, name: "Hammamet", region: "Cap Bon" },
  { id: 2, name: "Sousse", region: "Sahel" },
  { id: 3, name: "Djerba", region: "Sud" },
  { id: 4, name: "Monastir", region: "Sahel" },
  { id: 5, name: "Tunis", region: "Grand Tunis" },
  { id: 6, name: "Mahdia", region: "Sahel" },
  { id: 7, name: "Tabarka", region: "Nord-Ouest" },
  { id: 8, name: "Tozeur", region: "Sud-Ouest" },
  { id: 9, name: "Bizerte", region: "Nord" },
  { id: 10, name: "Nabeul", region: "Cap Bon" },
  { id: 11, name: "Sfax", region: "Sud" },
  { id: 12, name: "Kairouan", region: "Centre" },
]

const STAR_OPTIONS = [
  { value: 5, label: "5 Etoiles" },
  { value: 4, label: "4 Etoiles" },
  { value: 3, label: "3 Etoiles" },
  { value: 2, label: "2 Etoiles" },
]

// ============================================================================
// Component
// ============================================================================

export function HotelsTunisieSearch() {
  // City selection state
  const [selectedCity, setSelectedCity] = useState<City | null>(null)
  const [citySearchOpen, setCitySearchOpen] = useState(false)

  // Date selection state
  const [checkinDate, setCheckinDate] = useState<Date | undefined>()
  const [checkoutDate, setCheckoutDate] = useState<Date | undefined>()
  const [datePopoverOpen, setDatePopoverOpen] = useState(false)

  // Pax state
  const [adults, setAdults] = useState(2)
  const [childrenAges, setChildrenAges] = useState<number[]>([])
  const [paxPopoverOpen, setPaxPopoverOpen] = useState(false)

  // Filters state
  const [onlyAvailable, setOnlyAvailable] = useState(true)
  const [selectedStars, setSelectedStars] = useState<number[]>([])
  const [starsPopoverOpen, setStarsPopoverOpen] = useState(false)

  // Build the API request object
  const buildSearchRequest = useCallback((): HotelSearchRequest | null => {
    if (!selectedCity || !checkinDate || !checkoutDate) {
      return null
    }

    return {
      CityId: selectedCity.id,
      BookingDetails: {
        Checkin: format(checkinDate, "yyyy-MM-dd"),
        Checkout: format(checkoutDate, "yyyy-MM-dd"),
      },
      Pax: {
        Adult: adults,
        Child: childrenAges,
      },
      Filters: {
        OnlyAvailable: onlyAvailable,
        Category: selectedStars,
      },
    }
  }, [selectedCity, checkinDate, checkoutDate, adults, childrenAges, onlyAvailable, selectedStars])

  const handleSearch = () => {
    const request = buildSearchRequest()
    if (request) {
      console.log("[v0] HotelSearch Request:", JSON.stringify(request, null, 2))
      // TODO: Call MyGo API with request
    }
  }

  const isFormValid = selectedCity && checkinDate && checkoutDate

  // Children management
  const addChild = () => {
    if (childrenAges.length < 4) {
      setChildrenAges([...childrenAges, 5]) // Default age 5
    }
  }

  const removeChild = (index: number) => {
    setChildrenAges(childrenAges.filter((_, i) => i !== index))
  }

  const updateChildAge = (index: number, age: number) => {
    const newAges = [...childrenAges]
    newAges[index] = age
    setChildrenAges(newAges)
  }

  // Star filter toggle
  const toggleStar = (star: number) => {
    if (selectedStars.includes(star)) {
      setSelectedStars(selectedStars.filter(s => s !== star))
    } else {
      setSelectedStars([...selectedStars, star].sort((a, b) => b - a))
    }
  }

  // Date range display
  const dateRangeDisplay = useMemo(() => {
    if (checkinDate && checkoutDate) {
      return `${format(checkinDate, "dd MMM", { locale: fr })} - ${format(checkoutDate, "dd MMM yyyy", { locale: fr })}`
    }
    if (checkinDate) {
      return `${format(checkinDate, "dd MMM yyyy", { locale: fr })} - ...`
    }
    return "Sélectionner les dates"
  }, [checkinDate, checkoutDate])

  // Pax display
  const paxDisplay = useMemo(() => {
    const parts: string[] = []
    parts.push(`${adults} Adulte${adults > 1 ? "s" : ""}`)
    if (childrenAges.length > 0) {
      parts.push(`${childrenAges.length} Enfant${childrenAges.length > 1 ? "s" : ""}`)
    }
    return parts.join(", ")
  }, [adults, childrenAges])

  return (
    <div className="space-y-5">
      {/* Main Search Row */}
      <div className="flex flex-col lg:flex-row gap-3">
        {/* City Autocomplete */}
        <div className="flex-1 min-w-0">
          <label className="text-xs text-muted-foreground font-medium mb-1.5 block">
            Destination
          </label>
          <Popover open={citySearchOpen} onOpenChange={setCitySearchOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                role="combobox"
                aria-expanded={citySearchOpen}
                className="w-full justify-start rounded-3xl h-12 px-4 text-left font-normal"
              >
                <MapPin className="mr-2 size-4 shrink-0 text-muted-foreground" />
                {selectedCity ? (
                  <span className="truncate">
                    {selectedCity.name}
                    {selectedCity.region && (
                      <span className="text-muted-foreground ml-1">({selectedCity.region})</span>
                    )}
                  </span>
                ) : (
                  <span className="text-muted-foreground">Rechercher une ville...</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[320px] p-0" align="start">
              <Command>
                <CommandInput placeholder="Rechercher une ville..." />
                <CommandList>
                  <CommandEmpty>Aucune ville trouvée.</CommandEmpty>
                  <CommandGroup heading="Zones touristiques">
                    {TUNISIA_CITIES.map((city) => (
                      <CommandItem
                        key={city.id}
                        value={`${city.name} ${city.region || ""}`}
                        onSelect={() => {
                          setSelectedCity(city)
                          setCitySearchOpen(false)
                        }}
                      >
                        <MapPin className="mr-2 size-4 text-muted-foreground" />
                        <span>{city.name}</span>
                        {city.region && (
                          <span className="ml-auto text-xs text-muted-foreground">
                            {city.region}
                          </span>
                        )}
                        {selectedCity?.id === city.id && (
                          <Check className="ml-2 size-4 text-primary" />
                        )}
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </CommandList>
              </Command>
            </PopoverContent>
          </Popover>
        </div>

        {/* Date Range Picker */}
        <div className="flex-1 min-w-0">
          <label className="text-xs text-muted-foreground font-medium mb-1.5 block">
            Dates du séjour
          </label>
          <Popover open={datePopoverOpen} onOpenChange={setDatePopoverOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="w-full justify-start rounded-3xl h-12 px-4 text-left font-normal"
              >
                <Calendar className="mr-2 size-4 shrink-0 text-muted-foreground" />
                <span className={cn(!checkinDate && "text-muted-foreground", "truncate")}>
                  {dateRangeDisplay}
                </span>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <div className="p-3 border-b">
                <div className="flex items-center gap-4 text-sm">
                  <div className="flex-1">
                    <p className="text-muted-foreground text-xs">Check-in</p>
                    <p className="font-medium">
                      {checkinDate ? format(checkinDate, "dd/MM/yyyy") : "—"}
                    </p>
                  </div>
                  <div className="flex-1">
                    <p className="text-muted-foreground text-xs">Check-out</p>
                    <p className="font-medium">
                      {checkoutDate ? format(checkoutDate, "dd/MM/yyyy") : "—"}
                    </p>
                  </div>
                </div>
              </div>
              <CalendarComponent
                mode="range"
                selected={
                  checkinDate && checkoutDate
                    ? { from: checkinDate, to: checkoutDate }
                    : checkinDate
                    ? { from: checkinDate, to: undefined }
                    : undefined
                }
                onSelect={(range) => {
                  setCheckinDate(range?.from)
                  setCheckoutDate(range?.to)
                  if (range?.from && range?.to) {
                    setDatePopoverOpen(false)
                  }
                }}
                numberOfMonths={2}
                disabled={{ before: new Date() }}
                locale={fr}
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* Pax Selector */}
        <div className="flex-1 min-w-0">
          <label className="text-xs text-muted-foreground font-medium mb-1.5 block">
            Voyageurs
          </label>
          <Popover open={paxPopoverOpen} onOpenChange={setPaxPopoverOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="w-full justify-start rounded-3xl h-12 px-4 text-left font-normal"
              >
                <Users className="mr-2 size-4 shrink-0 text-muted-foreground" />
                <span className="truncate">{paxDisplay}</span>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[320px] p-4" align="start">
              <div className="space-y-4">
                {/* Adults */}
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Adultes</p>
                    <p className="text-xs text-muted-foreground">18 ans et plus</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button
                      variant="outline"
                      size="icon"
                      className="size-8 rounded-full"
                      onClick={() => setAdults(Math.max(1, adults - 1))}
                      disabled={adults <= 1}
                    >
                      <Minus className="size-3" />
                    </Button>
                    <span className="w-6 text-center font-medium">{adults}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      className="size-8 rounded-full"
                      onClick={() => setAdults(Math.min(6, adults + 1))}
                      disabled={adults >= 6}
                    >
                      <Plus className="size-3" />
                    </Button>
                  </div>
                </div>

                {/* Children Header */}
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Enfants</p>
                    <p className="text-xs text-muted-foreground">0-17 ans</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="rounded-full"
                    onClick={addChild}
                    disabled={childrenAges.length >= 4}
                  >
                    <Plus className="size-3 mr-1" />
                    Ajouter
                  </Button>
                </div>

                {/* Children Age Selectors */}
                {childrenAges.length > 0 && (
                  <div className="space-y-2 pl-2 border-l-2 border-muted">
                    {childrenAges.map((age, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <span className="text-sm text-muted-foreground w-16">
                          Enfant {index + 1}
                        </span>
                        <select
                          value={age}
                          onChange={(e) => updateChildAge(index, parseInt(e.target.value))}
                          className="flex h-9 w-full max-w-[100px] rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                        >
                          {Array.from({ length: 18 }, (_, i) => (
                            <option key={i} value={i}>
                              {i} an{i > 1 ? "s" : ""}
                            </option>
                          ))}
                        </select>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-7 text-muted-foreground hover:text-destructive"
                          onClick={() => removeChild(index)}
                        >
                          <X className="size-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </PopoverContent>
          </Popover>
        </div>

        {/* Search Button */}
        <div className="flex items-end">
          <Button
            onClick={handleSearch}
            disabled={!isFormValid}
            className="w-full lg:w-auto h-12 px-8 rounded-3xl bg-orange-500 hover:bg-orange-600 text-white font-semibold text-base shadow-lg hover:shadow-xl transition-all"
          >
            <Search className="size-5 mr-2" />
            RECHERCHER
          </Button>
        </div>
      </div>

      {/* Filters Row */}
      <div className="flex flex-wrap items-center gap-4 pt-1">
        {/* Only Available Checkbox */}
        <div className="flex items-center gap-2">
          <Checkbox
            id="only-available"
            checked={onlyAvailable}
            onCheckedChange={(checked) => setOnlyAvailable(checked === true)}
            className="rounded"
          />
          <label
            htmlFor="only-available"
            className="text-sm text-muted-foreground cursor-pointer select-none"
          >
            Disponibilité réelle uniquement
          </label>
        </div>

        {/* Star Category Filter */}
        <Popover open={starsPopoverOpen} onOpenChange={setStarsPopoverOpen}>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full h-8 gap-1.5"
            >
              <Star className="size-3.5 fill-amber-400 text-amber-400" />
              {selectedStars.length > 0 ? (
                <span>{selectedStars.join(", ")} étoiles</span>
              ) : (
                <span>Catégorie</span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-[200px] p-2" align="start">
            <div className="space-y-1">
              {STAR_OPTIONS.map((option) => (
                <button
                  key={option.value}
                  onClick={() => toggleStar(option.value)}
                  className={cn(
                    "flex items-center gap-2 w-full px-2 py-1.5 rounded-md text-sm transition-colors",
                    selectedStars.includes(option.value)
                      ? "bg-primary/10 text-primary"
                      : "hover:bg-muted"
                  )}
                >
                  <div className="flex items-center gap-0.5">
                    {Array.from({ length: option.value }).map((_, i) => (
                      <Star
                        key={i}
                        className="size-3 fill-amber-400 text-amber-400"
                      />
                    ))}
                  </div>
                  <span className="ml-auto">
                    {selectedStars.includes(option.value) && (
                      <Check className="size-4 text-primary" />
                    )}
                  </span>
                </button>
              ))}
            </div>
            {selectedStars.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="w-full mt-2 text-xs"
                onClick={() => setSelectedStars([])}
              >
                Effacer les filtres
              </Button>
            )}
          </PopoverContent>
        </Popover>

        {/* Active Filters Display */}
        {selectedStars.length > 0 && (
          <div className="flex items-center gap-1.5">
            {selectedStars.map((star) => (
              <Badge
                key={star}
                variant="secondary"
                className="rounded-full gap-1 pr-1"
              >
                {star}
                <Star className="size-2.5 fill-amber-400 text-amber-400" />
                <button
                  onClick={() => toggleStar(star)}
                  className="ml-0.5 hover:bg-muted-foreground/20 rounded-full p-0.5"
                >
                  <X className="size-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
